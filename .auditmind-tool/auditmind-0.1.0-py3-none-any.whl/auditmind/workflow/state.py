from __future__ import annotations

from typing import Any, TypedDict

from auditmind.domain.models import (
    ChangedFile,
    ContextBundle,
    Finding,
    PolicyDecision,
    ReviewRequest,
    ReviewResult,
    ScannerFinding,
    VerificationResult,
)


class ReviewState(TypedDict, total=False):
    request: ReviewRequest
    base_sha: str
    diff_base_sha: str
    head_sha: str
    changed_files: list[ChangedFile]
    context_snippets: ContextBundle
    scanner_findings: list[ScannerFinding]
    security_findings: list[Finding]
    correctness_findings: list[Finding]
    candidate_findings: list[Finding]
    verified_findings: list[Finding]
    verifications: list[VerificationResult]
    policy_decision: PolicyDecision
    report: ReviewResult
    errors: list[str]
    trace_id: str
    token_usage: int
    duration: float
    stages: list[dict[str, Any]]
