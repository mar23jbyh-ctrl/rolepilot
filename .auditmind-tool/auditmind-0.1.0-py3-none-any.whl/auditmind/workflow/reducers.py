from auditmind.domain.models import Finding


def deduplicate(findings: list[Finding]) -> list[Finding]:
    seen: set[tuple[str, int, str]] = set()
    unique = []
    for finding in sorted(findings, key=lambda f: (-f.confidence, f.fingerprint)):
        key = finding.file_path, finding.start_line, finding.rule_id
        if key not in seen:
            unique.append(finding)
            seen.add(key)
    return unique
