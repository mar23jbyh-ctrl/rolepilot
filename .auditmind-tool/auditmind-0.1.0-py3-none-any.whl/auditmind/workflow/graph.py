from langgraph.graph import END, START, StateGraph

from auditmind.workflow.nodes import Nodes
from auditmind.workflow.state import ReviewState


def build_graph(nodes: Nodes):
    graph = StateGraph(ReviewState)
    graph.add_node("diff", nodes.diff)
    graph.add_node("context", nodes.context)
    graph.add_node("scanners", nodes.scanners)
    graph.add_node("reviewers", nodes.reviewers)
    graph.add_node("verifier", nodes.verifier)
    graph.add_node("policy", nodes.policy_node)
    graph.add_node("report", nodes.report)
    graph.add_edge(START, "diff")
    graph.add_edge("diff", "context")
    graph.add_edge("context", "scanners")
    graph.add_edge("scanners", "reviewers")
    graph.add_edge("reviewers", "verifier")
    graph.add_edge("verifier", "policy")
    graph.add_edge("policy", "report")
    graph.add_edge("report", END)
    return graph.compile()
