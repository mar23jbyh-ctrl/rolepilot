from __future__ import annotations

import asyncio
import hashlib
import time
from pathlib import Path

from auditmind.agents import correctness_reviewer, security_reviewer
from auditmind.agents.evidence_verifier import verify
from auditmind.config import PolicyConfig, Settings
from auditmind.context.context_builder import build_context
from auditmind.domain.models import PolicyDecision, ReviewResult
from auditmind.git.repository import GitRepository
from auditmind.llm.client import ModelClient
from auditmind.observability.redaction import redact
from auditmind.policy.engine import decide
from auditmind.scanners import bandit, gitleaks, semgrep
from auditmind.workflow.reducers import deduplicate
from auditmind.workflow.state import ReviewState


class Nodes:
    def __init__(self, settings: Settings, policy: PolicyConfig, client: ModelClient | None):
        self.settings = settings
        self.policy = policy
        self.client = client
        self.started = time.monotonic()

    def diff(self, state: ReviewState) -> dict:
        started = time.monotonic()
        request = state["request"]
        repo = GitRepository(request.repo)
        base, head = repo.sha(request.base), repo.sha(request.head)
        diff_base = repo.merge_base(base, head)
        changed = repo.changed_files(diff_base, head)
        return {
            "base_sha": base,
            "diff_base_sha": diff_base,
            "head_sha": head,
            "changed_files": changed,
            "stages": [
                {
                    "name": "Diff Normalizer",
                    "status": "completed",
                    "duration": time.monotonic() - started,
                }
            ],
        }

    def context(self, state: ReviewState) -> dict:
        started = time.monotonic()
        repo = GitRepository(state["request"].repo)
        context = build_context(
            repo, state["head_sha"], state["changed_files"], state["request"].token_budget
        )
        return {
            "context_snippets": context,
            "stages": [
                *state["stages"],
                {
                    "name": "Context Extractor",
                    "status": "completed",
                    "duration": time.monotonic() - started,
                },
            ],
        }

    def scanners(self, state: ReviewState) -> dict:
        repo = Path(state["request"].repo)
        enabled = state["request"].scanners
        results = []
        stages = []
        for adapter in (semgrep, bandit, gitleaks):
            started = time.monotonic()
            scan_result = adapter.scan(repo, enabled)
            results.append(scan_result)
            stages.append(
                {
                    "name": scan_result.tool,
                    "status": scan_result.status,
                    "duration": time.monotonic() - started,
                }
            )
        context = state["context_snippets"].model_copy(deep=True)
        context.manifest.extend(
            f"scanner:{result.tool}:{result.status}:{len(result.findings)}" for result in results
        )
        return {
            "context_snippets": context,
            "scanner_findings": [f for result in results for f in result.findings],
            "errors": [f"{r.tool}: {r.error}" for r in results if r.error],
            "stages": [*state["stages"], *stages],
        }

    async def reviewers(self, state: ReviewState) -> dict:
        started = time.monotonic()
        request = state["request"]
        tasks = [
            security_reviewer.review(
                state["changed_files"], state["context_snippets"], request.offline, self.client
            ),
            correctness_reviewer.review(
                state["changed_files"], state["context_snippets"], request.offline, self.client
            ),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        reviewer_duration = time.monotonic() - started
        security = results[0] if isinstance(results[0], list) else []
        correctness = results[1] if isinstance(results[1], list) else []
        errors = [
            f"Reviewer {index + 1}: {type(result).__name__}: {result}"
            for index, result in enumerate(results)
            if isinstance(result, Exception)
        ]
        filter_started = time.monotonic()
        candidates = deduplicate([*security, *correctness])
        filter_duration = time.monotonic() - filter_started
        return {
            "security_findings": security,
            "correctness_findings": correctness,
            "candidate_findings": candidates,
            "errors": [*state["errors"], *errors],
            "token_usage": self.client.token_usage if self.client else 0,
            "stages": [
                *state["stages"],
                {
                    "name": "Security Reviewer",
                    "status": "completed" if not isinstance(results[0], Exception) else "failed",
                    "duration": reviewer_duration,
                },
                {
                    "name": "Contract & Correctness Reviewer",
                    "status": "completed" if not isinstance(results[1], Exception) else "failed",
                    "duration": reviewer_duration,
                },
                {"name": "Orchestrator Filter", "status": "completed", "duration": filter_duration},
            ],
        }

    def verifier(self, state: ReviewState) -> dict:
        started = time.monotonic()
        repo = GitRepository(state["request"].repo)
        results = [
            verify(
                f,
                state["changed_files"],
                repo,
                state["diff_base_sha"],
                state["head_sha"],
                state["scanner_findings"],
            )
            for f in state["candidate_findings"]
        ]
        by_id = {item.fingerprint: item for item in results}
        verified = [
            f.model_copy(update={"verification_status": by_id[f.fingerprint].status})
            for f in state["candidate_findings"]
        ]
        verified = [f for f in verified if f.verification_status != "rejected"]
        return {
            "verifications": results,
            "verified_findings": verified,
            "stages": [
                *state["stages"],
                {
                    "name": "Evidence Verifier",
                    "status": "completed",
                    "duration": time.monotonic() - started,
                },
            ],
        }

    def policy_node(self, state: ReviewState) -> dict:
        started = time.monotonic()
        if any(
            stage["status"] == "failed"
            and stage["name"] in ("Security Reviewer", "Contract & Correctness Reviewer")
            for stage in state["stages"]
        ):
            return {
                "policy_decision": PolicyDecision(
                    status="FAILED",
                    blocked=True,
                    reason="Reviewer failed; CI requires a successful review",
                ),
                "stages": [
                    *state["stages"],
                    {
                        "name": "Policy Decision",
                        "status": "completed",
                        "duration": time.monotonic() - started,
                    },
                ],
            }
        return {
            "policy_decision": decide(state["verified_findings"], self.policy),
            "stages": [
                *state["stages"],
                {
                    "name": "Policy Decision",
                    "status": "completed",
                    "duration": time.monotonic() - started,
                },
            ],
        }

    def report(self, state: ReviewState) -> dict:
        request = state["request"]
        identity = (
            f"{Path(request.repo).resolve()}:{state['base_sha']}:"
            f"{state['head_sha']}:{request.offline}"
        )
        review_id = hashlib.sha256(identity.encode()).hexdigest()[:16]
        duration = time.monotonic() - self.started
        visible = state["verified_findings"][: self.policy.max_findings_per_pr]
        errors = list(state["errors"])
        if len(visible) < len(state["verified_findings"]):
            errors.append("Finding display limit reached; policy evaluated all findings")
        public_files = [
            file.model_copy(
                update={
                    "lines": [
                        line.model_copy(update={"text": redact(line.text)}) for line in file.lines
                    ]
                }
            )
            for file in state["changed_files"]
        ]
        public_context = state["context_snippets"].model_copy(
            update={
                "snippets": [
                    snippet.model_copy(update={"code": redact(snippet.code)})
                    for snippet in state["context_snippets"].snippets
                ]
            }
        )
        public_findings = [
            finding.model_copy(
                update={
                    "evidence": finding.evidence.model_copy(
                        update={"code": redact(finding.evidence.code)}
                    ),
                    "description": redact(finding.description),
                    "attack_path": redact(finding.attack_path),
                    "suggestion": redact(finding.suggestion),
                }
            )
            for finding in visible
        ]
        result = ReviewResult(
            review_id=review_id,
            trace_id=state["trace_id"],
            request=request,
            base_sha=state["base_sha"],
            diff_base_sha=state["diff_base_sha"],
            head_sha=state["head_sha"],
            changed_files=public_files,
            context=public_context,
            scanner_findings=[
                finding.model_copy(update={"message": redact(finding.message)})
                for finding in state["scanner_findings"]
            ],
            findings=public_findings,
            verifications=state["verifications"],
            policy=state["policy_decision"],
            errors=[redact(error) for error in errors],
            token_usage=state["token_usage"],
            duration_seconds=duration,
            mode="mock" if request.offline else "online",
            stages=state["stages"],
        )
        return {"report": result, "duration": duration}
