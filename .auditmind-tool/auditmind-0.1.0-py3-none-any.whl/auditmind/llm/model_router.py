from auditmind.config import Settings


def mode(settings: Settings, offline: bool) -> str:
    if offline:
        return "mock"
    if not settings.openai_api_key:
        raise ValueError("OPENAI_API_KEY is required for online reviews; use --offline")
    return "online"
