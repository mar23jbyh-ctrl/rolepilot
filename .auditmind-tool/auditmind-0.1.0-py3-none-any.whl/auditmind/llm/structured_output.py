from pydantic import BaseModel, Field

from auditmind.domain.models import Finding


class ReviewerOutput(BaseModel):
    findings: list[Finding] = Field(default_factory=list)
