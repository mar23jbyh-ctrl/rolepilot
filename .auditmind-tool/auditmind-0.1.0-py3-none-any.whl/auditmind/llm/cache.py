import hashlib
import sqlite3
from pathlib import Path


class ModelCache:
    def __init__(self, path: str | Path):
        self.path = str(path)
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS model_cache (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
            )

    @staticmethod
    def key(model: str, prompt: str) -> str:
        return hashlib.sha256((model + "\0" + prompt).encode()).hexdigest()

    def get(self, key: str) -> str | None:
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT value FROM model_cache WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def put(self, key: str, value: str) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute("INSERT OR REPLACE INTO model_cache VALUES (?,?)", (key, value))
