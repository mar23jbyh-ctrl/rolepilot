"""Model clients and structured responses."""
