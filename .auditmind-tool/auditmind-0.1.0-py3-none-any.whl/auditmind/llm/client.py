from __future__ import annotations

import asyncio
import json

from openai import AsyncOpenAI, OpenAIError
from pydantic import ValidationError

from auditmind.config import Settings
from auditmind.domain.errors import ModelError
from auditmind.llm.cache import ModelCache
from auditmind.llm.structured_output import ReviewerOutput


class ModelClient:
    def __init__(
        self, settings: Settings, cache: ModelCache | None = None, default_timeout: int = 30
    ):
        self.settings = settings
        self.cache = cache
        self.token_usage = 0
        self.default_timeout = default_timeout

    async def review(self, system: str, content: str, timeout: int | None = None) -> ReviewerOutput:
        timeout = timeout or self.default_timeout
        if not self.settings.openai_api_key:
            raise ModelError("OPENAI_API_KEY is missing")
        key = ModelCache.key(self.settings.auditmind_model, system + content)
        if self.cache and (cached := self.cache.get(key)):
            return self._parse(cached)
        client = AsyncOpenAI(
            api_key=self.settings.openai_api_key,
            base_url=self.settings.openai_base_url,
            timeout=timeout,
        )
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                response = await asyncio.wait_for(
                    client.chat.completions.create(
                        model=self.settings.auditmind_model,
                        temperature=0,
                        response_format={"type": "json_object"},
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user", "content": content},
                        ],
                    ),
                    timeout=timeout,
                )
                self.token_usage += response.usage.total_tokens if response.usage else 0
                output = response.choices[0].message.content or ""
                parsed = self._parse(output)
                if self.cache:
                    self.cache.put(key, output)
                return parsed
            except (OpenAIError, TimeoutError, ModelError, IndexError) as exc:
                last_error = exc
                if attempt < 2:
                    await asyncio.sleep(0.2 * (attempt + 1))
        raise ModelError(f"Model call failed after 3 attempts: {type(last_error).__name__}")

    @staticmethod
    def _parse(text: str) -> ReviewerOutput:
        try:
            return ReviewerOutput.model_validate(json.loads(text))
        except (ValueError, ValidationError) as exc:
            raise ModelError("Model returned invalid structured output") from exc
