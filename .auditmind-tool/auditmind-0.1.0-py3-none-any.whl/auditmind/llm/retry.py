import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


async def limited_retry(call: Callable[[], Awaitable[T]], attempts: int = 3) -> T:
    for index in range(attempts):
        try:
            return await call()
        except (TimeoutError, ConnectionError):
            if index == attempts - 1:
                raise
            await asyncio.sleep(0.2 * (index + 1))
    raise RuntimeError("Unreachable retry state")
