from __future__ import annotations

from pathlib import Path

from auditmind.config import Settings


def allowed_repository(raw_path: str, settings: Settings) -> Path:
    """Resolve a repository inside an operator-configured directory boundary."""
    try:
        path = Path(raw_path).resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise ValueError("Repository path is unavailable") from exc
    if not path.is_dir():
        raise ValueError("Repository path is not a directory")
    roots = [
        Path(item.strip()).resolve()
        for item in settings.auditmind_allowed_repo_roots.split(";")
        if item.strip()
    ]
    if not roots or not any(path == root or path.is_relative_to(root) for root in roots):
        raise ValueError("Repository path is outside configured roots")
    if not (path / ".git").exists():
        raise ValueError("Repository path is not a Git checkout")
    return path
