import sqlite3
from pathlib import Path


def connect(path: str | Path) -> sqlite3.Connection:
    db = sqlite3.connect(str(path))
    db.execute(
        "CREATE TABLE IF NOT EXISTS reviews (id TEXT PRIMARY KEY, created_at TEXT, result TEXT)"
    )
    db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS context_fts USING fts5(review_id, path, symbol)")
    db.execute(
        "CREATE TABLE IF NOT EXISTS review_jobs ("
        "id TEXT PRIMARY KEY, request TEXT NOT NULL, status TEXT NOT NULL, "
        "result_id TEXT, error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)"
    )
    return db
