"""SQLite run metadata."""
