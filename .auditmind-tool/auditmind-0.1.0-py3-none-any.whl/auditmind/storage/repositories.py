from __future__ import annotations

from pathlib import Path

from auditmind.domain.models import ReviewResult
from auditmind.storage.sqlite import connect


class ReviewRepository:
    def __init__(self, db_path: str | Path):
        self.db_path = db_path

    def save(self, result: ReviewResult) -> None:
        with connect(self.db_path) as db:
            db.execute(
                "INSERT OR REPLACE INTO reviews VALUES (?,?,?)",
                (result.review_id, result.created_at.isoformat(), result.model_dump_json()),
            )
            db.execute("DELETE FROM context_fts WHERE review_id=?", (result.review_id,))
            db.executemany(
                "INSERT INTO context_fts VALUES (?,?,?)",
                [
                    (result.review_id, snippet.file_path, snippet.symbol or snippet.kind)
                    for snippet in result.context.snippets
                ],
            )

    def get(self, review_id: str) -> ReviewResult | None:
        with connect(self.db_path) as db:
            row = db.execute("SELECT result FROM reviews WHERE id=?", (review_id,)).fetchone()
        return ReviewResult.model_validate_json(row[0]) if row else None

    def list(self, limit: int = 50) -> list[ReviewResult]:
        with connect(self.db_path) as db:
            rows = db.execute(
                "SELECT result FROM reviews ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [ReviewResult.model_validate_json(row[0]) for row in rows]
