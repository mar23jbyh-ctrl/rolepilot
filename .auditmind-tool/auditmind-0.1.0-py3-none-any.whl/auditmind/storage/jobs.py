from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from auditmind.domain.models import ReviewRequest
from auditmind.storage.sqlite import connect


class JobRepository:
    def __init__(self, db_path: str | Path):
        self.db_path = db_path

    def create(self, job_id: str, request: ReviewRequest) -> dict:
        now = datetime.now(UTC).isoformat()
        with connect(self.db_path) as db:
            db.execute(
                "INSERT OR IGNORE INTO review_jobs VALUES (?,?,?,?,?,?,?)",
                (job_id, request.model_dump_json(), "queued", None, None, now, now),
            )
        return self.get(job_id) or {}

    def get(self, job_id: str) -> dict | None:
        with connect(self.db_path) as db:
            row = db.execute(
                "SELECT id,status,result_id,error,created_at,updated_at "
                "FROM review_jobs WHERE id=?", (job_id,)
            ).fetchone()
        if row is None:
            return None
        return dict(zip(
            ("job_id", "status", "review_id", "error", "created_at", "updated_at"),
            row,
            strict=True,
        ))

    def request(self, job_id: str) -> ReviewRequest | None:
        with connect(self.db_path) as db:
            row = db.execute("SELECT request FROM review_jobs WHERE id=?", (job_id,)).fetchone()
        return ReviewRequest.model_validate(json.loads(row[0])) if row else None

    def fail_interrupted(self) -> None:
        now = datetime.now(UTC).isoformat()
        with connect(self.db_path) as db:
            db.execute(
                "UPDATE review_jobs SET status='failed', error='Server restarted during review', "
                "updated_at=? WHERE status IN ('queued','running')", (now,)
            )

    def update(self, job_id: str, status: str, result_id: str | None = None,
               error: str | None = None) -> None:
        now = datetime.now(UTC).isoformat()
        with connect(self.db_path) as db:
            db.execute(
                "UPDATE review_jobs SET status=?,result_id=?,error=?,updated_at=? WHERE id=?",
                (status, result_id, error, now, job_id),
            )

    def list(self, limit: int = 50) -> list[dict]:
        with connect(self.db_path) as db:
            rows = db.execute(
                "SELECT id FROM review_jobs ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [item for row in rows if (item := self.get(row[0])) is not None]
