from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import shutil
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse

from auditmind.config import Settings, load_policy
from auditmind.domain.errors import GitError
from auditmind.domain.models import ReviewRequest, ReviewResult
from auditmind.git.repository import GitRepository
from auditmind.security import allowed_repository
from auditmind.service import run_review
from auditmind.storage.jobs import JobRepository
from auditmind.storage.repositories import ReviewRepository


@asynccontextmanager
async def lifespan(_app: FastAPI):
    JobRepository(Settings().auditmind_db_path).fail_interrupted()
    yield
    active = list(_active_jobs.values())
    for task in active:
        task.cancel()
    if active:
        await asyncio.gather(*active, return_exceptions=True)


app = FastAPI(title="AuditMind API", version="0.1.0", lifespan=lifespan)
router = APIRouter()


def authorize(request: Request, authorization: str | None = Header(None)) -> None:
    settings = Settings()
    if settings.auditmind_api_token:
        expected = f"Bearer {settings.auditmind_api_token}"
        if not authorization or not hmac.compare_digest(authorization, expected):
            raise HTTPException(401, "API authentication required")
        return
    host = request.client.host if request.client else ""
    if host not in ("127.0.0.1", "::1", "localhost", "testclient"):
        raise HTTPException(503, "Configure AUDITMIND_API_TOKEN for remote API access")


protected = APIRouter(dependencies=[Depends(authorize)])
_active_jobs: dict[str, asyncio.Task] = {}
_job_slots = asyncio.Semaphore(2)


def jobs() -> JobRepository:
    return JobRepository(Settings().auditmind_db_path)


async def _run_job(job_id: str, review_request: ReviewRequest, cache: bool = True) -> None:
    async with _job_slots:
        repository = jobs()
        repository.update(job_id, "running")
        try:
            result = await run_review(review_request, cache=cache)
            repository.update(job_id, "completed", result.review_id)
        except asyncio.CancelledError:
            repository.update(job_id, "cancelled", error="Review was cancelled")
            raise
        except Exception as exc:
            repository.update(job_id, "failed", error=f"Review failed: {type(exc).__name__}")


@protected.post("/review-jobs", status_code=202)
async def create_review_job(review_request: ReviewRequest, force: bool = False) -> dict:
    try:
        safe_repo = allowed_repository(review_request.repo, Settings())
        git = GitRepository(safe_repo)
        request = review_request.model_copy(update={
            "repo": str(safe_repo), "base": git.sha(review_request.base),
            "head": git.sha(review_request.head),
        })
    except (ValueError, FileNotFoundError, GitError) as exc:
        raise HTTPException(400, str(exc)) from exc
    seed = request.model_dump_json()
    if force:
        seed += os.urandom(16).hex()
    job_id = hashlib.sha256(seed.encode()).hexdigest()[:20]
    record = jobs().create(job_id, request)
    if record["status"] == "queued" and job_id not in _active_jobs:
        task = asyncio.create_task(_run_job(job_id, request, cache=not force))
        _active_jobs[job_id] = task
        task.add_done_callback(lambda _: _active_jobs.pop(job_id, None))
    return record


@protected.get("/review-jobs")
def list_review_jobs() -> list[dict]:
    return jobs().list()


@protected.get("/review-jobs/{job_id}")
def get_review_job(job_id: str) -> dict:
    record = jobs().get(job_id)
    if record is None:
        raise HTTPException(404, "Review job not found")
    return record


@protected.post("/review-jobs/{job_id}/cancel")
def cancel_review_job(job_id: str) -> dict:
    record = jobs().get(job_id)
    if record is None:
        raise HTTPException(404, "Review job not found")
    task = _active_jobs.get(job_id)
    if task and not task.done():
        task.cancel()
        jobs().update(job_id, "cancelled", error="Review was cancelled")
    return jobs().get(job_id) or record


@protected.post("/review-jobs/{job_id}/retry", status_code=202)
async def retry_review_job(job_id: str) -> dict:
    record = jobs().get(job_id)
    if record is None:
        raise HTTPException(404, "Review job not found")
    if record["status"] not in ("failed", "cancelled"):
        raise HTTPException(409, "Only failed or cancelled reviews can be retried")
    original_request = jobs().request(job_id)
    if original_request is None:
        raise HTTPException(404, "Review request not found")
    return await create_review_job(original_request, force=True)


@app.middleware("http")
async def limit_request_size(request: Request, call_next):
    length = request.headers.get("content-length")
    if length:
        try:
            oversized = int(length) > Settings().auditmind_max_request_bytes
        except ValueError:
            return JSONResponse({"detail": "Invalid Content-Length"}, status_code=400)
        if oversized:
            return JSONResponse(
                {"detail": "Request body exceeds configured limit"}, status_code=413
            )
    return await call_next(request)


def store() -> ReviewRepository:
    return ReviewRepository(Settings().auditmind_db_path)


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "mode": "offline" if Settings().auditmind_offline else "online"}


@protected.post("/reviews", response_model=ReviewResult)
async def create_review(request: ReviewRequest) -> ReviewResult:
    try:
        safe_repo = allowed_repository(request.repo, Settings())
        return await run_review(request.model_copy(update={"repo": str(safe_repo)}))
    except (ValueError, FileNotFoundError, GitError) as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(422, f"Review failed: {type(exc).__name__}") from exc


@protected.get("/reviews", response_model=list[ReviewResult])
def list_reviews() -> list[ReviewResult]:
    return store().list()


def found(review_id: str) -> ReviewResult:
    result = store().get(review_id)
    if not result:
        raise HTTPException(404, "Review not found")
    return result


@protected.get("/reviews/{review_id}", response_model=ReviewResult)
def get_review(review_id: str) -> ReviewResult:
    return found(review_id)


@protected.get("/reviews/{review_id}/findings")
def get_findings(review_id: str) -> list:
    return found(review_id).findings


@protected.get("/reviews/{review_id}/diff")
def get_diff(review_id: str) -> list:
    return found(review_id).changed_files


@protected.get("/evaluation/summary")
def evaluation_summary() -> dict:
    online = Path("eval/baselines/online_summary.json")
    if online.exists():
        return json.loads(online.read_text(encoding="utf-8"))
    return {
        "mode": "unavailable",
        "groups": [],
        "message": "Run auditmind eval --online to generate real model metrics",
    }


@protected.get("/system/status")
def system_status() -> dict:
    settings = Settings()
    policy = load_policy(".")
    return {
        "api": "available",
        "provider": "configured" if settings.openai_api_key else "not configured",
        "model": settings.auditmind_model,
        "base_url": "configured" if settings.openai_base_url else "not configured",
        "api_key": "configured" if settings.openai_api_key else "not configured",
        "git": "available" if shutil.which("git") else "unavailable",
        "semgrep": "available" if shutil.which("semgrep") else "skipped",
        "bandit": "available" if shutil.which("bandit") else "skipped",
        "gitleaks": "available" if shutil.which("gitleaks") else "skipped",
        "sqlite": "available",
        "policy": policy.model_dump(mode="json"),
    }


@router.post("/webhooks/github")
async def github_webhook(request: Request, x_hub_signature_256: str | None = Header(None)) -> dict:
    secret = os.getenv("AUDITMIND_GITHUB_WEBHOOK_SECRET")
    if not secret:
        raise HTTPException(503, "GitHub webhook secret is not configured")
    body = await request.body()
    digest = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    if not x_hub_signature_256 or not hmac.compare_digest(digest, x_hub_signature_256):
        raise HTTPException(401, "Invalid webhook signature")
    event = await request.json()
    if event.get("action") not in ("opened", "reopened", "synchronize"):
        return {"status": "ignored"}
    # The local checkout must be configured explicitly. Never trust a repo path in webhook JSON.
    repo = os.getenv("AUDITMIND_WEBHOOK_REPO")
    if not repo:
        raise HTTPException(503, "AUDITMIND_WEBHOOK_REPO is not configured")
    pr = event.get("pull_request", {})
    try:
        safe_repo = allowed_repository(repo, Settings())
        base_sha = pr["base"]["sha"]
        head_sha = pr["head"]["sha"]
    except (ValueError, KeyError) as exc:
        raise HTTPException(400, "Invalid webhook repository or PR payload") from exc
    result = await run_review(
        ReviewRequest(
            repo=str(safe_repo),
            base=base_sha,
            head=head_sha,
            offline=Settings().auditmind_offline,
        )
    )
    return {"review_id": result.review_id, "status": result.policy.status}


app.include_router(router)
app.include_router(router, prefix="/api", include_in_schema=False)
app.include_router(protected)
app.include_router(protected, prefix="/api", include_in_schema=False)
