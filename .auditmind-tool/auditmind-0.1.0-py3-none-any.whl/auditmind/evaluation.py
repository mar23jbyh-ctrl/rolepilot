from __future__ import annotations

import difflib
import hashlib
import json
import math
import random
import time
from asyncio import gather
from pathlib import Path

from auditmind.agents import correctness_reviewer, security_reviewer
from auditmind.agents.evidence_verifier import verify
from auditmind.agents.mock_rules import mock_review, rule_for_line
from auditmind.config import Settings
from auditmind.domain.enums import Category
from auditmind.domain.models import ChangedFile, ChangedLine, ContextBundle, ContextSnippet
from auditmind.llm.client import ModelClient
from auditmind.workflow.reducers import deduplicate

GROUPS = [
    "Full File + Single Agent",
    "Diff + Single Agent",
    "Diff + Context + Single Agent",
    "Diff + Context + Multi-Agent",
    "Diff + Context + Multi-Agent + Verifier",
]


class _MemoryRepository:
    """Read-only source adapter for labeled evaluation cases."""

    def __init__(self, base: str, head: str):
        self.base = base
        self.head = head

    def source(self, ref: str, path: str) -> str:
        return self.head if ref == "head" else self.base


def synthetic_diff(base: str, head: str, path: str = "app.py") -> ChangedFile:
    old, new = base.splitlines(), head.splitlines()
    lines = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=old, b=new).get_opcodes():
        if tag in ("equal", "delete", "replace"):
            lines.extend(
                ChangedLine(
                    kind="context" if tag == "equal" else "delete",
                    old_line=i + 1,
                    new_line=j1 + i - i1 + 1 if tag == "equal" else None,
                    text=old[i],
                )
                for i in range(i1, i2)
            )
        if tag in ("insert", "replace"):
            lines.extend(
                ChangedLine(kind="add", new_line=j + 1, text=new[j]) for j in range(j1, j2)
            )
    return ChangedFile(path=path, status="modified", lines=lines)


def _safe_ratio(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 1.0


def _wilson_95(successes: int, trials: int) -> list[float] | None:
    """Descriptive binomial interval; it does not fix selection or label bias."""
    if trials == 0:
        return None
    z = 1.96
    p = successes / trials
    denominator = 1 + z * z / trials
    center = (p + z * z / (2 * trials)) / denominator
    margin = z * math.sqrt(p * (1 - p) / trials + z * z / (4 * trials * trials))
    margin /= denominator
    return [round(max(0.0, center - margin), 4), round(min(1.0, center + margin), 4)]


def run_dataset(path: str | Path) -> dict:
    cases = [
        json.loads(line)
        for line in Path(path).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    groups = []
    for index, name in enumerate(GROUPS):
        tp = fp = fn = high_tp = high_total = located = blocking_correct = failures = 0
        estimated_tokens = 0
        started = time.perf_counter()
        for case in cases:
            try:
                file = synthetic_diff(case["base"], case["head"], case.get("file", "app.py"))
                if index == 0:
                    file.lines = [
                        ChangedLine(kind="add", new_line=i + 1, text=row)
                        for i, row in enumerate(case["head"].splitlines())
                    ]
                categories = [Category.SECURITY] if index <= 2 else list(Category)
                predictions = [f for category in categories for f in mock_review([file], category)]
                if index == 4:
                    predictions = [
                        f
                        for f in predictions
                        if f.side == "LEFT"
                        or rule_for_line(case["head"].splitlines()[f.start_line - 1], f.category)
                        == f.rule_id
                    ]
                expected = {(item["rule_id"], item["line"]) for item in case["expected"]}
                predicted = {(f.rule_id, f.start_line) for f in predictions}
                expected_rules = {rule for rule, _ in expected}
                predicted_rules = {rule for rule, _ in predicted}
                tp += len(expected_rules & predicted_rules)
                fp += len(predicted_rules - expected_rules)
                fn += len(expected_rules - predicted_rules)
                located += len(expected & predicted)
                high = {
                    item["rule_id"]
                    for item in case["expected"]
                    if item["severity"] in ("HIGH", "CRITICAL")
                }
                high_total += len(high)
                high_tp += len(high & predicted_rules)
                blocked = any(f.severity in ("HIGH", "CRITICAL") for f in predictions)
                expected_blocked = bool(high)
                blocking_correct += blocked == expected_blocked
                material = (
                    case["head"]
                    if index == 0
                    else "\n".join(item.text for item in file.lines if item.kind == "add")
                )
                estimated_tokens += max(1, len(material) // 4)
            except (KeyError, ValueError, IndexError):
                failures += 1
        elapsed = time.perf_counter() - started
        groups.append(
            {
                "name": name,
                "precision": _safe_ratio(tp, tp + fp),
                "recall": _safe_ratio(tp, tp + fn),
                "high_severity_recall": _safe_ratio(high_tp, high_total),
                "false_positives": fp,
                "false_positives_per_pr": round(fp / len(cases), 4),
                "line_accuracy": _safe_ratio(located, tp),
                "latency_ms": round(1000 * elapsed / len(cases), 4),
                "token_usage": 0,
                "estimated_context_tokens": estimated_tokens,
                "blocking_accuracy": _safe_ratio(blocking_correct, len(cases)),
                "failure_rate": _safe_ratio(failures, len(cases)),
            }
        )
    distribution = {
        severity: sum(item["severity"] == severity for case in cases for item in case["expected"])
        for severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
    }
    return {
        "mode": "mock",
        "case_count": len(cases),
        "groups": groups,
        "severity_distribution": distribution,
        "note": (
            "Mock heuristics only. token_usage=0 actual model tokens; "
            "estimated_context_tokens is a character estimate. "
            "Results do not represent LLM quality."
        ),
    }


async def run_online_dataset(
    path: str | Path,
    settings: Settings | None = None,
    max_cases: int | None = None,
    seed: int = 20260921,
) -> dict:
    """Run the production reviewer stack against labeled cases using a real model.

    This intentionally reports one production configuration instead of fabricating
    ablation groups from the same model response. Precision and recall are relative
    to the labels in the dataset and must not be read as universal model accuracy.
    """
    settings = settings or Settings()
    if not settings.openai_api_key:
        raise ValueError("OPENAI_API_KEY is required for online evaluation")
    dataset_bytes = Path(path).read_bytes()
    cases = [
        json.loads(line)
        for line in dataset_bytes.decode("utf-8").splitlines()
        if line.strip()
    ]
    if max_cases is not None:
        if max_cases < 1:
            raise ValueError("max_cases must be positive")
        cases = random.Random(seed).sample(cases, min(max_cases, len(cases)))
    # Cache hits would report zero billed tokens and distort measured latency.
    client = ModelClient(settings, cache=None, default_timeout=60)
    tp = fp = fn = high_tp = high_total = located = blocking_correct = failures = 0
    started = time.perf_counter()
    severity_distribution = {severity: 0 for severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW")}
    case_outcomes = []

    for case in cases:
        expected = {(item["rule_id"], item["line"]) for item in case["expected"]}
        expected_rules = {rule for rule, _ in expected}
        high = {
            item["rule_id"]
            for item in case["expected"]
            if item["severity"] in ("HIGH", "CRITICAL")
        }
        high_total += len(high)
        for item in case["expected"]:
            severity_distribution[item["severity"]] += 1
        case_started = time.perf_counter()
        try:
            file = synthetic_diff(case["base"], case["head"], case.get("file", "app.py"))
            context = ContextBundle(
                snippets=[
                    ContextSnippet(
                        file_path=file.path,
                        start_line=1,
                        end_line=max(1, len(case["head"].splitlines())),
                        kind="evaluation_context",
                        code=case["head"],
                        score=100,
                    )
                ],
                manifest=["labeled evaluation context"],
                token_estimate=max(1, len(case["head"]) // 4),
            )
            results = await gather(
                security_reviewer.review([file], context, False, client),
                correctness_reviewer.review([file], context, False, client),
                return_exceptions=True,
            )
            if any(isinstance(item, Exception) for item in results):
                raise RuntimeError("reviewer failed")
            predictions = deduplicate([item for result in results for item in result])
            memory_repo = _MemoryRepository(case["base"], case["head"])
            verifications = [
                verify(finding, [file], memory_repo, "base", "head", [])
                for finding in predictions
            ]
            predictions = [
                finding.model_copy(update={"verification_status": verification.status})
                for finding, verification in zip(predictions, verifications, strict=True)
                if verification.status != "rejected"
            ]
            predicted = {(finding.rule_id, finding.start_line) for finding in predictions}
            predicted_rules = {rule for rule, _ in predicted}
            tp += len(expected_rules & predicted_rules)
            fp += len(predicted_rules - expected_rules)
            fn += len(expected_rules - predicted_rules)
            located += len(expected & predicted)
            high_tp += len(high & predicted_rules)
            blocked = any(
                finding.verification_status == "confirmed"
                and finding.severity in ("HIGH", "CRITICAL")
                for finding in predictions
            )
            blocking_correct += blocked == bool(high)
            case_outcomes.append({
                "id": case["id"], "status": "completed", "expected_rules": sorted(expected_rules),
                "predicted_rules": sorted(predicted_rules), "blocked": blocked,
                "expected_blocked": bool(high),
                "latency_ms": round((time.perf_counter() - case_started) * 1000, 2),
            })
        except (KeyError, ValueError, IndexError, TypeError, RuntimeError) as exc:
            failures += 1
            fn += len(expected_rules)
            case_outcomes.append({
                "id": case.get("id"), "status": "failed", "error_type": type(exc).__name__,
                "expected_rules": sorted(expected_rules), "predicted_rules": [],
                "blocked": None, "expected_blocked": bool(high),
                "latency_ms": round((time.perf_counter() - case_started) * 1000, 2),
            })

    elapsed = time.perf_counter() - started
    count = len(cases)
    group = {
        "name": GROUPS[-1],
        "true_positives": tp,
        "false_negatives": fn,
        "high_true_positives": high_tp,
        "high_expected_total": high_total,
        "failed_cases": failures,
        "precision": _safe_ratio(tp, tp + fp),
        "recall": _safe_ratio(tp, tp + fn),
        "high_severity_recall": _safe_ratio(high_tp, high_total),
        "false_positives": fp,
        "false_positives_per_pr": round(fp / count, 4) if count else 0,
        "line_accuracy": _safe_ratio(located, tp),
        "latency_ms": round(1000 * elapsed / count, 4) if count else 0,
        "token_usage": client.token_usage,
        "estimated_context_tokens": 0,
        "blocking_accuracy": _safe_ratio(blocking_correct, count),
        "failure_rate": _safe_ratio(failures, count),
        "wilson_95": {
            "precision": _wilson_95(tp, tp + fp),
            "recall": _wilson_95(tp, tp + fn),
            "high_severity_recall": _wilson_95(high_tp, high_total),
            "blocking_accuracy": _wilson_95(blocking_correct, count),
        },
    }
    return {
        "mode": "online",
        "model": settings.auditmind_model,
        "dataset_sha256": hashlib.sha256(dataset_bytes).hexdigest(),
        "sample_seed": seed,
        "sampled_case_ids": [case["id"] for case in cases],
        "cache_enabled": False,
        "case_count": count,
        "case_outcomes": case_outcomes,
        "groups": [group],
        "severity_distribution": severity_distribution,
        "note": (
            "Real OpenAI-compatible model calls against the labeled dataset. "
            "Metrics are dataset-relative and cover the production multi-agent + verifier "
            "configuration; "
            "Failed cases count as false negatives and incorrect CI decisions. "
            "Subset sampling is seeded. No response cache is used. "
            "These labels are synthetic and do not establish field accuracy."
        ),
    }
