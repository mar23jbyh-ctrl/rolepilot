from __future__ import annotations

import subprocess
from pathlib import Path


def demo_repository(root: Path) -> Path:
    source = root / "examples" / "vulnerable-fastapi-repo"
    destination = root / ".auditmind-demo"
    if (destination / ".git").is_dir():
        return destination
    if not source.is_dir():
        raise FileNotFoundError("Offline demo fixture is missing")
    destination.mkdir(exist_ok=True)

    def git(*args: str) -> None:
        subprocess.run(
            ["git", "-C", str(destination), *args], check=True, capture_output=True, timeout=30
        )

    git("init", "-q")
    git("config", "user.name", "AuditMind Demo")
    git("config", "user.email", "demo@auditmind.invalid")
    target = destination / "app.py"
    target.write_text((source / "base.py").read_text(encoding="utf-8"), encoding="utf-8")
    git("add", "app.py")
    git("commit", "-qm", "safe baseline")
    target.write_text((source / "head.py").read_text(encoding="utf-8"), encoding="utf-8")
    git("add", "app.py")
    git("commit", "-qm", "introduce sample SQL injection")
    return destination
