from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from auditmind.domain.enums import Category, Severity


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    openai_api_key: str | None = None
    openai_base_url: str = "https://api.openai.com/v1"
    auditmind_model: str = "gpt-4o-mini"
    # Real model reviews are the default. Use --offline explicitly for the
    # deterministic local fixture and pipeline regression tests.
    auditmind_offline: bool = False
    auditmind_log_level: str = "INFO"
    auditmind_db_path: str = ".auditmind.db"
    github_token: str | None = None
    auditmind_api_token: str | None = None
    auditmind_allowed_repo_roots: str = "."
    auditmind_max_request_bytes: int = Field(default=1048576, ge=1024)


class PolicyConfig(BaseModel):
    fail_on: list[Severity] = Field(default_factory=lambda: [Severity.CRITICAL, Severity.HIGH])
    categories: list[Category] = Field(default_factory=lambda: list(Category))
    require_evidence: bool = True
    allow_uncertain: bool = True
    max_findings_per_pr: int = Field(default=50, ge=1)
    ignore_rules: list[str] = Field(default_factory=list)
    ignore_paths: list[str] = Field(default_factory=list)
    comment_mode: str = "summary"
    model: str = "gpt-4o-mini"
    token_budget: int = Field(default=6000, ge=256)
    timeout_seconds: int = Field(default=30, ge=1, le=300)

    def ignored(self, rule: str, path: str) -> bool:
        return rule in self.ignore_rules or any(fnmatch(path, p) for p in self.ignore_paths)


def load_policy(repo: str | Path) -> PolicyConfig:
    path = Path(repo) / ".auditmind.yml"
    if not path.is_file():
        return PolicyConfig()
    content = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return PolicyConfig.model_validate(content)
