from __future__ import annotations

import json
from importlib.resources import files as resource_files

from auditmind.agents.mock_rules import mock_review
from auditmind.domain.enums import Category
from auditmind.domain.models import ChangedFile, ContextBundle, Finding
from auditmind.llm.client import ModelClient
from auditmind.llm.structured_output import ReviewerOutput


async def review(
    changed: list[ChangedFile],
    context: ContextBundle,
    offline: bool,
    client: ModelClient | None = None,
) -> list[Finding]:
    if offline:
        return mock_review(changed, Category.CORRECTNESS)
    assert client is not None
    prompt = resource_files("auditmind.agents.prompts").joinpath("correctness.txt").read_text()
    data = {
        "changed_files": [file.model_dump() for file in changed],
        "context": context.model_dump(),
    }
    schema = json.dumps(ReviewerOutput.model_json_schema())
    response = await client.review(
        prompt + "\nRequired JSON Schema:\n" + schema,
        "UNTRUSTED REPOSITORY DATA:\n" + json.dumps(data),
    )
    return [finding for finding in response.findings if finding.category == Category.CORRECTNESS]
