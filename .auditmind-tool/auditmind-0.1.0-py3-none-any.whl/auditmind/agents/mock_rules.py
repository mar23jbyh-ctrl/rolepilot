from __future__ import annotations

import hashlib
import re

from auditmind.domain.enums import Category, Severity, Side
from auditmind.domain.models import ChangedFile, Evidence, Finding

RULES: dict[str, tuple[Category, Severity, str, str]] = {
    "AM-SQL-001": (
        Category.SECURITY,
        Severity.HIGH,
        "SQL query interpolates input",
        "Use parameterized queries.",
    ),
    "AM-CMD-001": (
        Category.SECURITY,
        Severity.HIGH,
        "Shell command uses dynamic input",
        "Avoid shell=True and pass an argument list.",
    ),
    "AM-SECRET-001": (
        Category.SECURITY,
        Severity.HIGH,
        "Hard-coded credential",
        "Use a secret manager or environment variable.",
    ),
    "AM-SSRF-001": (
        Category.SECURITY,
        Severity.HIGH,
        "HTTP request uses dynamic URL",
        "Validate destination against an allowlist.",
    ),
    "AM-PATH-001": (
        Category.SECURITY,
        Severity.HIGH,
        "File path uses dynamic input",
        "Resolve and constrain paths to an allowed root.",
    ),
    "AM-DESER-001": (
        Category.SECURITY,
        Severity.HIGH,
        "Unsafe deserialization",
        "Use a safe data format and parser.",
    ),
    "AM-API-001": (
        Category.CORRECTNESS,
        Severity.MEDIUM,
        "API route was removed",
        "Preserve the route or document a versioned migration.",
    ),
    "AM-EXCEPT-001": (
        Category.CORRECTNESS,
        Severity.MEDIUM,
        "Exception is silently swallowed",
        "Handle or re-raise the exception.",
    ),
    "AM-DB-001": (
        Category.CORRECTNESS,
        Severity.MEDIUM,
        "Database write lacks transaction completion",
        "Commit or use a transaction context.",
    ),
    "AM-AUTH-001": (
        Category.SECURITY,
        Severity.HIGH,
        "Authorization guard was removed",
        "Restore an equivalent ownership check.",
    ),
    "AM-CONC-001": (
        Category.CORRECTNESS,
        Severity.MEDIUM,
        "Shared counter changed without synchronization",
        "Use a lock or atomic storage operation.",
    ),
}


def rule_for_line(text: str, category: Category) -> str | None:
    line = text.strip()
    if line.startswith("#"):
        return None
    if category == Category.SECURITY:
        if re.search(r"(?:execute|executemany)\s*\(.*(?:f['\"]|\.format\(|\+\s*\w)", line):
            return "AM-SQL-001"
        if re.search(r"(?:subprocess\.(?:run|Popen|call)|os\.system)\s*\(.*shell\s*=\s*True", line):
            return "AM-CMD-001"
        if re.search(r"\b(?:password|api_key|secret|token)\s*=\s*['\"][^'\"]{6,}['\"]", line, re.I):
            return "AM-SECRET-001"
        if re.search(
            r"requests\.(?:get|post|put|delete)\s*\(\s*(?:url|user_url|target_url|request\.)", line
        ):
            return "AM-SSRF-001"
        if re.search(r"(?:open|Path)\s*\(\s*(?:request\.|user_path|filename)", line):
            return "AM-PATH-001"
        if re.search(r"\b(?:pickle\.loads?|yaml\.load)\s*\(", line):
            return "AM-DESER-001"
    else:
        if re.search(r"except\s+.*:\s*pass\b", line):
            return "AM-EXCEPT-001"
        if re.search(r"\bdb\.(?:add|delete)\s*\(", line) and "with db.begin" not in line:
            return "AM-DB-001"
        if line == "counter += 1":
            return "AM-CONC-001"
    return None


def make_finding(
    file: ChangedFile, line_no: int, text: str, rule_id: str, side: Side = Side.RIGHT
) -> Finding:
    category, severity, title, suggestion = RULES[rule_id]
    fingerprint = hashlib.sha256(f"{file.path}:{line_no}:{rule_id}".encode()).hexdigest()[:16]
    # Evidence is the smallest stable code fragment, so secret literals are never reported.
    evidence = text.strip()
    if rule_id == "AM-SECRET-001":
        evidence = re.match(r"\s*\w+\s*=", text).group(0).strip()  # type: ignore[union-attr]
    return Finding(
        fingerprint=fingerprint,
        file_path=file.path,
        start_line=line_no,
        end_line=line_no,
        side=side,
        rule_id=rule_id,
        category=category,
        severity=severity,
        title=title,
        evidence=Evidence(code=evidence, line=line_no, source="changed_line"),
        description=title,
        attack_path="Potential data flow at changed line",
        suggestion=suggestion,
        source_agent="Security Reviewer"
        if category == Category.SECURITY
        else "Contract & Correctness Reviewer",
        confidence=0.8,
    )


def mock_review(files: list[ChangedFile], category: Category) -> list[Finding]:
    findings = []
    for file in files:
        if not file.path.endswith(".py"):
            continue
        for line in file.lines:
            if line.kind != "add" or line.new_line is None:
                continue
            rule = rule_for_line(line.text, category)
            if rule:
                findings.append(make_finding(file, line.new_line, line.text, rule))
        if category == Category.SECURITY:
            removed_guards = [
                line
                for line in file.lines
                if line.kind == "delete"
                and line.old_line
                and "current_user.id" in line.text
                and "user_id" in line.text
            ]
            for line in removed_guards:
                findings.append(
                    make_finding(file, line.old_line, line.text, "AM-AUTH-001", Side.LEFT)
                )
        if category == Category.CORRECTNESS:
            removed = [
                line
                for line in file.lines
                if line.kind == "delete" and line.text.lstrip().startswith(("@app.", "@router."))
            ]
            added_routes = [
                line.text.strip()
                for line in file.lines
                if line.kind == "add" and line.text.lstrip().startswith(("@app.", "@router."))
            ]
            for line in removed:
                if line.text.strip() not in added_routes and line.old_line:
                    findings.append(
                        make_finding(file, line.old_line, line.text, "AM-API-001", Side.LEFT)
                    )
    return findings
