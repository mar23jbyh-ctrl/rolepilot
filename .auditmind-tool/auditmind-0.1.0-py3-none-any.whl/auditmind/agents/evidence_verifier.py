from __future__ import annotations

import ast
import re

from auditmind.agents.mock_rules import rule_for_line
from auditmind.context.python_parser import enclosing, parse_python
from auditmind.domain.enums import VerificationStatus
from auditmind.domain.models import ChangedFile, Finding, ScannerFinding, VerificationResult
from auditmind.git.repository import GitRepository


def _sql_query_flows_to_execute(source: str, line: int) -> bool:
    """Corroborate a direct function argument in a SQL f-string reaching execute."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return False
    functions = [
        node
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.lineno <= line <= (node.end_lineno or node.lineno)
    ]
    if not functions:
        return False
    function = min(functions, key=lambda node: (node.end_lineno or node.lineno) - node.lineno)
    arguments = {
        arg.arg for arg in function.args.posonlyargs + function.args.args + function.args.kwonlyargs
    }
    for index, statement in enumerate(function.body):
        if not isinstance(statement, (ast.Assign, ast.AnnAssign)):
            continue
        targets = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
        if len(targets) != 1 or not isinstance(targets[0], ast.Name):
            continue
        name = targets[0].id
        value = statement.value
        if not isinstance(value, ast.JoinedStr):
            continue
        literals = "".join(
            part.value
            for part in value.values
            if isinstance(part, ast.Constant) and isinstance(part.value, str)
        )
        if not re.search(r"\b(?:SELECT|INSERT|UPDATE|DELETE)\b", literals, re.I):
            continue
        direct_inputs = [
            part.value for part in value.values if isinstance(part, ast.FormattedValue)
        ]
        if not any(
            isinstance(input_value, ast.Name)
            and input_value.id in arguments
            or isinstance(input_value, ast.Attribute)
            and isinstance(input_value.value, ast.Name)
            and input_value.value.id in arguments
            for input_value in direct_inputs
        ):
            continue
        for later in function.body[index + 1 :]:
            if isinstance(later, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                later_targets = later.targets if isinstance(later, ast.Assign) else [later.target]
                if any(
                    isinstance(target, ast.Name) and target.id == name for target in later_targets
                ):
                    break
            for call in (node for node in ast.walk(later) if isinstance(node, ast.Call)):
                if (
                    isinstance(call.func, ast.Attribute)
                    and call.func.attr in {"execute", "executemany"}
                    and call.args
                    and isinstance(call.args[0], ast.Name)
                    and call.args[0].id == name
                    and line in {statement.lineno, call.lineno}
                ):
                    return True
    return False


def verify(
    finding: Finding,
    changed: list[ChangedFile],
    repo: GitRepository,
    base: str,
    head: str,
    scanners: list[ScannerFinding],
) -> VerificationResult:
    file = next((item for item in changed if item.path == finding.file_path), None)
    if not file:
        return VerificationResult(
            fingerprint=finding.fingerprint,
            status="rejected",
            reason="File is not in this diff",
            line_valid=False,
            evidence_valid=False,
        )
    ref = head if finding.side == "RIGHT" else base
    path = file.path if finding.side == "RIGHT" else file.old_path or file.path
    source = repo.source(ref, path)
    rows = source.splitlines() if source is not None else []
    line = finding.start_line
    changed_line = next(
        (
            item
            for item in file.lines
            if (item.new_line == line and item.kind == "add" and finding.side == "RIGHT")
            or (item.old_line == line and item.kind == "delete" and finding.side == "LEFT")
        ),
        None,
    )
    line_valid = changed_line is not None and 1 <= line <= len(rows)
    evidence_valid = bool(
        line_valid and finding.evidence.code in rows[line - 1] and finding.evidence.line == line
    )
    if not line_valid or not evidence_valid:
        return VerificationResult(
            fingerprint=finding.fingerprint,
            status="rejected",
            reason="Evidence or line does not match changed source",
            line_valid=line_valid,
            evidence_valid=evidence_valid,
        )
    scanner_match = any(
        item.file_path == finding.file_path
        and item.line == line
        and item.rule_id == finding.rule_id
        for item in scanners
    )
    semantic = (finding.rule_id in ("AM-API-001", "AM-AUTH-001") and finding.side == "LEFT") or (
        finding.side == "RIGHT"
        and rule_for_line(rows[line - 1], finding.category) == finding.rule_id
    )
    if finding.rule_id == "AM-SQL-001" and finding.side == "RIGHT":
        semantic = semantic or _sql_query_flows_to_execute(source or "", line)
    if finding.rule_id in ("AM-DB-001", "AM-CONC-001", "AM-AUTH-001"):
        semantic = False
    status = (
        VerificationStatus.CONFIRMED if semantic or scanner_match else VerificationStatus.UNCERTAIN
    )
    parsed = parse_python(source or "")
    symbol = enclosing(parsed, line)
    return VerificationResult(
        fingerprint=finding.fingerprint,
        status=status,
        reason="Changed source and rule corroborate finding"
        if status == "confirmed"
        else "Source matches but risk needs human review",
        line_valid=True,
        evidence_valid=True,
        ast_symbol=symbol.name if symbol else None,
        scanner_match=scanner_match,
    )
