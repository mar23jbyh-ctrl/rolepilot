from __future__ import annotations

from auditmind.agents.mock_rules import rule_for_line
from auditmind.context.python_parser import enclosing, parse_python
from auditmind.domain.enums import VerificationStatus
from auditmind.domain.models import ChangedFile, Finding, ScannerFinding, VerificationResult
from auditmind.git.repository import GitRepository


def verify(
    finding: Finding,
    changed: list[ChangedFile],
    repo: GitRepository,
    base: str,
    head: str,
    scanners: list[ScannerFinding],
) -> VerificationResult:
    file = next((item for item in changed if item.path == finding.file_path), None)
    if not file:
        return VerificationResult(
            fingerprint=finding.fingerprint,
            status="rejected",
            reason="File is not in this diff",
            line_valid=False,
            evidence_valid=False,
        )
    ref = head if finding.side == "RIGHT" else base
    path = file.path if finding.side == "RIGHT" else file.old_path or file.path
    source = repo.source(ref, path)
    rows = source.splitlines() if source is not None else []
    line = finding.start_line
    changed_line = next(
        (
            item
            for item in file.lines
            if (item.new_line == line and item.kind == "add" and finding.side == "RIGHT")
            or (item.old_line == line and item.kind == "delete" and finding.side == "LEFT")
        ),
        None,
    )
    line_valid = changed_line is not None and 1 <= line <= len(rows)
    evidence_valid = bool(
        line_valid and finding.evidence.code in rows[line - 1] and finding.evidence.line == line
    )
    if not line_valid or not evidence_valid:
        return VerificationResult(
            fingerprint=finding.fingerprint,
            status="rejected",
            reason="Evidence or line does not match changed source",
            line_valid=line_valid,
            evidence_valid=evidence_valid,
        )
    scanner_match = any(
        item.file_path == finding.file_path
        and item.line == line
        and item.rule_id == finding.rule_id
        for item in scanners
    )
    semantic = (finding.rule_id in ("AM-API-001", "AM-AUTH-001") and finding.side == "LEFT") or (
        finding.side == "RIGHT"
        and rule_for_line(rows[line - 1], finding.category) == finding.rule_id
    )
    if finding.rule_id in ("AM-DB-001", "AM-CONC-001", "AM-AUTH-001"):
        semantic = False
    status = (
        VerificationStatus.CONFIRMED if semantic or scanner_match else VerificationStatus.UNCERTAIN
    )
    parsed = parse_python(source or "")
    symbol = enclosing(parsed, line)
    return VerificationResult(
        fingerprint=finding.fingerprint,
        status=status,
        reason="Changed source and rule corroborate finding"
        if status == "confirmed"
        else "Source matches but risk needs human review",
        line_valid=True,
        evidence_valid=True,
        ast_symbol=symbol.name if symbol else None,
        scanner_match=scanner_match,
    )
