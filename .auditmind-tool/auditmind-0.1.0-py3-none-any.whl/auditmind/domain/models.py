from __future__ import annotations

from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from auditmind.domain.enums import Category, Severity, Side, VerificationStatus


class ReviewRequest(BaseModel):
    repo: str = "."
    base: str = "HEAD~1"
    head: str = "HEAD"
    offline: bool = False
    model: str | None = None
    scanners: bool = False
    token_budget: int = Field(default=6000, ge=256, le=100000)


class ChangedLine(BaseModel):
    kind: str
    old_line: int | None = Field(default=None, ge=1)
    new_line: int | None = Field(default=None, ge=1)
    text: str


class ChangedFile(BaseModel):
    path: str
    old_path: str | None = None
    status: str
    lines: list[ChangedLine] = Field(default_factory=list)
    is_binary: bool = False

    @field_validator("path", "old_path")
    @classmethod
    def safe_path(cls, value: str | None) -> str | None:
        if value is None:
            return value
        normalized = value.replace("\\", "/")
        path = PurePosixPath(normalized)
        if (
            not normalized
            or normalized.startswith("/")
            or ":" in normalized
            or ".." in path.parts
            or normalized.startswith("~")
        ):
            raise ValueError("Unsafe repository path")
        return normalized


class ContextSnippet(BaseModel):
    file_path: str
    start_line: int = Field(ge=1)
    end_line: int = Field(ge=1)
    kind: str
    symbol: str | None = None
    code: str
    score: float = 0


class ContextBundle(BaseModel):
    snippets: list[ContextSnippet] = Field(default_factory=list)
    manifest: list[str] = Field(default_factory=list)
    incomplete: bool = False
    token_estimate: int = 0


class ScannerFinding(BaseModel):
    tool: str
    rule_id: str
    file_path: str
    line: int = Field(ge=1)
    severity: Severity
    message: str


class Evidence(BaseModel):
    code: str = Field(min_length=1)
    line: int = Field(ge=1)
    source: str


class Finding(BaseModel):
    fingerprint: str
    file_path: str
    start_line: int = Field(ge=1)
    end_line: int = Field(ge=1)
    side: Side = Side.RIGHT
    rule_id: str = Field(min_length=1)
    category: Category
    severity: Severity
    title: str = Field(min_length=1)
    evidence: Evidence
    description: str = ""
    attack_path: str = ""
    suggestion: str = ""
    source_agent: str
    confidence: float = Field(ge=0, le=1)
    verification_status: VerificationStatus = VerificationStatus.UNCERTAIN

    @field_validator("file_path")
    @classmethod
    def safe_file(cls, value: str) -> str:
        return ChangedFile.safe_path(value) or ""

    @model_validator(mode="after")
    def valid_span(self) -> Finding:
        if self.end_line < self.start_line:
            raise ValueError("end_line precedes start_line")
        return self


class VerificationResult(BaseModel):
    fingerprint: str
    status: VerificationStatus
    reason: str
    line_valid: bool
    evidence_valid: bool
    ast_symbol: str | None = None
    scanner_match: bool = False


class PolicyDecision(BaseModel):
    status: str
    blocked: bool
    reason: str
    triggering_rules: list[str] = Field(default_factory=list)
    config_source: str = ".auditmind.yml"


class ReviewResult(BaseModel):
    review_id: str
    trace_id: str
    request: ReviewRequest
    base_sha: str
    diff_base_sha: str | None = None
    head_sha: str
    changed_files: list[ChangedFile]
    context: ContextBundle
    scanner_findings: list[ScannerFinding] = Field(default_factory=list)
    findings: list[Finding] = Field(default_factory=list)
    verifications: list[VerificationResult] = Field(default_factory=list)
    policy: PolicyDecision
    errors: list[str] = Field(default_factory=list)
    token_usage: int = 0
    duration_seconds: float = 0
    mode: str = "online"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    stages: list[dict[str, Any]] = Field(default_factory=list)

    @property
    def repo_name(self) -> str:
        return Path(self.request.repo).name
