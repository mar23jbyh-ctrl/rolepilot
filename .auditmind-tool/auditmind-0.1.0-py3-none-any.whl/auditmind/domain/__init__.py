"""Domain types."""
