from enum import StrEnum


class Severity(StrEnum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class Category(StrEnum):
    SECURITY = "security"
    CORRECTNESS = "correctness"


class VerificationStatus(StrEnum):
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    UNCERTAIN = "uncertain"


class Side(StrEnum):
    RIGHT = "RIGHT"
    LEFT = "LEFT"
