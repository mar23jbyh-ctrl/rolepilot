class AuditMindError(Exception):
    """Expected review failure with a safe message."""


class GitError(AuditMindError):
    """Git operation failed."""


class ModelError(AuditMindError):
    """Model request or structured response failed."""
