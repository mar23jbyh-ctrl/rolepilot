import logging

import structlog


def configure(level: str = "INFO") -> None:
    logging.basicConfig(level=level)
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ]
    )


def event(name: str, trace_id: str, **metadata: str | int | float) -> None:
    # Callers supply metadata only. Repository source and credentials are never logged.
    structlog.get_logger().info(name, trace_id=trace_id, **metadata)
