"""Safe telemetry."""
