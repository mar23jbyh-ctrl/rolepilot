from __future__ import annotations

import re

ASSIGNMENT = re.compile(r"(?i)\b(password|api_key|secret|token)\s*=\s*(['\"])[^'\"\r\n]{6,}\2")
TOKEN = re.compile(r"\b(?:sk|ghp|gho|glpat)-?[A-Za-z0-9_-]{20,}\b")


def redact(text: str) -> str:
    text = ASSIGNMENT.sub(lambda match: f'{match.group(1)} = "<redacted>"', text)
    return TOKEN.sub("<redacted-token>", text)
