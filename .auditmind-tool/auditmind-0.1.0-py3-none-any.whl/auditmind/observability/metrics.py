from auditmind.domain.models import ReviewResult


def run_metrics(result: ReviewResult) -> dict[str, float | int]:
    return {
        "duration_seconds": result.duration_seconds,
        "token_usage": result.token_usage,
        "finding_count": len(result.findings),
    }
