from __future__ import annotations

from dataclasses import dataclass, field

from auditmind.domain.models import ScannerFinding


@dataclass
class ScanResult:
    tool: str
    status: str
    findings: list[ScannerFinding] = field(default_factory=list)
    error: str | None = None
