from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from auditmind.domain.enums import Severity
from auditmind.domain.models import ScannerFinding
from auditmind.scanners.base import ScanResult


def scan(repo: Path, enabled: bool) -> ScanResult:
    if not enabled or not shutil.which("gitleaks"):
        return ScanResult("gitleaks", "skipped")
    try:
        result = subprocess.run(
            [
                "gitleaks",
                "dir",
                str(repo),
                "--report-format",
                "json",
                "--report-path",
                "-",
                "--no-banner",
                "--redact",
            ],
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        if result.returncode not in (0, 1):
            return ScanResult("gitleaks", "failed", error="Gitleaks scan failed")
        findings = []
        for item in json.loads(result.stdout or "[]"):
            path = str(Path(item["File"]).resolve().relative_to(repo.resolve())).replace("\\", "/")
            findings.append(
                ScannerFinding(
                    tool="gitleaks",
                    rule_id=item["RuleID"],
                    file_path=path,
                    line=item["StartLine"],
                    severity=Severity.HIGH,
                    message="Potential secret detected (redacted)",
                )
            )
        return ScanResult("gitleaks", "completed", findings)
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return ScanResult("gitleaks", "failed", error="Gitleaks output could not be normalized")
