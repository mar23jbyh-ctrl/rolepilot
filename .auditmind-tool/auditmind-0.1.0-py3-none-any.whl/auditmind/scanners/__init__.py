"""Optional deterministic scanner adapters."""
