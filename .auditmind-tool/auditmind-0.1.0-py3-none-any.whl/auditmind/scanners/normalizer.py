from auditmind.domain.enums import Severity


def severity(value: str) -> Severity:
    value = value.upper()
    return {"ERROR": Severity.HIGH, "WARNING": Severity.MEDIUM, "INFO": Severity.LOW}.get(
        value, Severity(value) if value in Severity._value2member_map_ else Severity.MEDIUM
    )
