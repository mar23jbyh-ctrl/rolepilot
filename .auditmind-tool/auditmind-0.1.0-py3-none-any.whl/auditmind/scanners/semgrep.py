from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from auditmind.domain.models import ScannerFinding
from auditmind.scanners.base import ScanResult
from auditmind.scanners.normalizer import severity


def scan(repo: Path, enabled: bool) -> ScanResult:
    if not enabled or not shutil.which("semgrep"):
        return ScanResult("semgrep", "skipped")
    try:
        result = subprocess.run(
            ["semgrep", "scan", "--config", "auto", "--json", "--metrics=off", "--", str(repo)],
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        if result.returncode not in (0, 1):
            return ScanResult("semgrep", "failed", error="Semgrep scan failed")
        data = json.loads(result.stdout)
        findings = [
            ScannerFinding(
                tool="semgrep",
                rule_id=item["check_id"],
                file_path=str(Path(item["path"]).resolve().relative_to(repo.resolve())).replace(
                    "\\", "/"
                ),
                line=item["start"]["line"],
                severity=severity(item["extra"]["severity"]),
                message=item["extra"]["message"][:300],
            )
            for item in data.get("results", [])
        ]
        return ScanResult("semgrep", "completed", findings)
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return ScanResult("semgrep", "failed", error="Semgrep output could not be normalized")
