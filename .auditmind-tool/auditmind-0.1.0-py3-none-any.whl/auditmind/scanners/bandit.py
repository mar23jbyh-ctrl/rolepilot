from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from auditmind.domain.models import ScannerFinding
from auditmind.scanners.base import ScanResult
from auditmind.scanners.normalizer import severity


def scan(repo: Path, enabled: bool) -> ScanResult:
    if not enabled or not shutil.which("bandit"):
        return ScanResult("bandit", "skipped")
    try:
        result = subprocess.run(
            ["bandit", "-r", str(repo), "-f", "json", "-q"],
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        data = json.loads(result.stdout)
        findings = [
            ScannerFinding(
                tool="bandit",
                rule_id=item["test_id"],
                file_path=str(Path(item["filename"]).resolve().relative_to(repo.resolve())).replace(
                    "\\", "/"
                ),
                line=item["line_number"],
                severity=severity(item["issue_severity"]),
                message=item["issue_text"][:300],
            )
            for item in data.get("results", [])
        ]
        return ScanResult("bandit", "completed", findings)
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return ScanResult("bandit", "failed", error="Bandit output could not be normalized")
