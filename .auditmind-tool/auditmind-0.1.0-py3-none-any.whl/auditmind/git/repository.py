from __future__ import annotations

import subprocess
from pathlib import Path

from auditmind.domain.errors import GitError
from auditmind.domain.models import ChangedFile
from auditmind.git.diff_parser import parse_diff


class GitRepository:
    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        if not self.path.is_dir():
            raise GitError("Repository path does not exist")
        self.run("rev-parse", "--show-toplevel")

    def run(self, *args: str) -> str:
        result = subprocess.run(
            ["git", "-C", str(self.path), *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
        if result.returncode:
            raise GitError(f"Git {args[0]} failed: {result.stderr.strip()[:300]}")
        return result.stdout

    def sha(self, ref: str) -> str:
        # --end-of-options keeps a malicious ref from becoming a Git option.
        return self.run("rev-parse", "--verify", "--end-of-options", ref + "^{commit}").strip()

    def merge_base(self, base: str, head: str) -> str:
        """PR patches start at the common ancestor, not the moving base tip."""
        return self.run("merge-base", base, head).strip()

    def changed_files(self, base: str, head: str) -> list[ChangedFile]:
        output = self.run(
            "diff", "--no-ext-diff", "--no-color", "--find-renames", "--unified=3", base, head, "--"
        )
        return parse_diff(output)

    def tracked_paths(self, ref: str) -> list[str]:
        safe = []
        for path in self.run("ls-tree", "-r", "--name-only", ref, "--").splitlines():
            if not path.endswith(".py"):
                continue
            try:
                ChangedFile.safe_path(path)
            except ValueError:
                continue
            safe.append(path)
        return safe

    def source(self, ref: str, path: str) -> str | None:
        ChangedFile.safe_path(path)
        # File content is read as data; no target code is imported or executed.
        result = subprocess.run(
            ["git", "-C", str(self.path), "show", f"{ref}:{path}"],
            capture_output=True,
            timeout=30,
            check=False,
        )
        if result.returncode or b"\0" in result.stdout:
            return None
        return result.stdout.decode("utf-8", errors="replace")
