"""Read-only Git inspection."""
