from __future__ import annotations

import re
import shlex

from auditmind.domain.models import ChangedFile, ChangedLine

HUNK = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def parse_diff(raw: str) -> list[ChangedFile]:
    files: list[ChangedFile] = []
    current: ChangedFile | None = None
    old_no = new_no = 0
    for line in raw.splitlines():
        if line.startswith("diff --git "):
            if current and not current.is_binary:
                files.append(current)
            parts = shlex.split(line[len("diff --git ") :])
            if len(parts) != 2:
                current = None
                continue
            current = ChangedFile(path=parts[1][2:], old_path=parts[0][2:], status="modified")
            continue
        if current is None:
            continue
        if line.startswith("new file mode "):
            current.status = "added"
        elif line.startswith("deleted file mode "):
            current.status = "deleted"
        elif line.startswith("rename from "):
            current.status = "renamed"
            current.old_path = line[len("rename from ") :]
        elif line.startswith("rename to "):
            current.path = ChangedFile.safe_path(line[len("rename to ") :]) or ""
        elif line.startswith("Binary files ") or line.startswith("GIT binary patch"):
            current.is_binary = True
        elif match := HUNK.match(line):
            old_no, new_no = int(match[1]), int(match[2])
        elif line.startswith("+++") or line.startswith("---") or line.startswith("\\"):
            continue
        elif line.startswith("+"):
            current.lines.append(ChangedLine(kind="add", new_line=new_no, text=line[1:]))
            new_no += 1
        elif line.startswith("-"):
            current.lines.append(ChangedLine(kind="delete", old_line=old_no, text=line[1:]))
            old_no += 1
        elif line.startswith(" ") and old_no and new_no:
            current.lines.append(
                ChangedLine(kind="context", old_line=old_no, new_line=new_no, text=line[1:])
            )
            old_no += 1
            new_no += 1
    if current and not current.is_binary:
        files.append(current)
    return files
