from auditmind.domain.models import ChangedFile


def changed_positions(file: ChangedFile) -> set[tuple[str, int]]:
    return {
        ("RIGHT", line.new_line)
        for line in file.lines
        if line.kind == "add" and line.new_line is not None
    } | {
        ("LEFT", line.old_line)
        for line in file.lines
        if line.kind == "delete" and line.old_line is not None
    }


def old_to_new(file: ChangedFile, old_line: int) -> int | None:
    return next((line.new_line for line in file.lines if line.old_line == old_line), None)
