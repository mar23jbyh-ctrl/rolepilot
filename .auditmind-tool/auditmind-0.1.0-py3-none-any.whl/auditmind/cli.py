from __future__ import annotations

import asyncio
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import httpx
import typer

from auditmind.config import Settings, load_policy
from auditmind.demo import demo_repository
from auditmind.domain.models import ReviewRequest
from auditmind.publishers.github_checks import publish_check
from auditmind.publishers.github_comments import publish_comment
from auditmind.publishers.json import render as json_render
from auditmind.publishers.markdown import render as markdown_render
from auditmind.service import run_review
from auditmind.storage.repositories import ReviewRepository

app = typer.Typer(help="AuditMind evidence-grounded PR review gate", no_args_is_help=True)


@app.command()
def review(
    repo: str = typer.Option(".", help="Repository path"),
    base: str = typer.Option("HEAD~1"),
    head: str = typer.Option("HEAD"),
    offline: bool | None = typer.Option(None, "--offline/--online"),
    scanners: bool = typer.Option(False, "--scanners"),
    format: str = typer.Option("markdown", "--format"),
    publish_github: bool = typer.Option(False, "--publish-github"),
) -> None:
    """Review a Git range without executing repository code."""
    settings = Settings()
    offline = settings.auditmind_offline if offline is None else offline
    if format not in ("json", "markdown"):
        raise typer.BadParameter("format must be json or markdown")
    try:
        if repo == "." and offline and not (Path(".git").is_dir()):
            repo = str(demo_repository(Path.cwd()))
        request = ReviewRequest(
            repo=repo,
            base=base,
            head=head,
            offline=offline,
            scanners=scanners,
            token_budget=load_policy(repo).token_budget,
        )
        result = asyncio.run(run_review(request, settings))
        if publish_github:
            asyncio.run(_publish(result, settings))
        typer.echo(json_render(result) if format == "json" else markdown_render(result))
        if result.policy.blocked:
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as exc:
        typer.echo(f"Review failed: {type(exc).__name__}: {exc}", err=True)
        raise typer.Exit(2) from exc


async def _publish(result, settings: Settings) -> None:
    full_repo = os.getenv("GITHUB_REPOSITORY", "")
    pr = os.getenv("AUDITMIND_PR_NUMBER", "")
    if not settings.github_token or "/" not in full_repo or not pr.isdigit():
        raise ValueError("GITHUB_TOKEN, GITHUB_REPOSITORY and AUDITMIND_PR_NUMBER required")
    owner, repo = full_repo.split("/", 1)
    async with httpx.AsyncClient(
        base_url="https://api.github.com",
        timeout=30,
        headers={
            "Authorization": f"Bearer {settings.github_token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    ) as client:
        await publish_check(client, owner, repo, result)
        if load_policy(result.request.repo).comment_mode != "none":
            await publish_comment(client, owner, repo, int(pr), result)


@app.command()
def explain(finding: str = typer.Option(..., "--finding")) -> None:
    """Show stored evidence and verification for a finding fingerprint."""
    for result in ReviewRepository(Settings().auditmind_db_path).list(100):
        item = next((f for f in result.findings if f.fingerprint == finding), None)
        if item:
            verification = next((v for v in result.verifications if v.fingerprint == finding), None)
            typer.echo(
                json.dumps(
                    {
                        "finding": item.model_dump(mode="json"),
                        "verification": verification.model_dump(mode="json")
                        if verification
                        else None,
                    },
                    indent=2,
                )
            )
            return
    typer.echo("Finding not found", err=True)
    raise typer.Exit(1)


@app.command()
def doctor() -> None:
    """Check local runtime without exposing credentials."""
    settings = Settings()
    try:
        is_git_repository = (
            bool(shutil.which("git"))
            and subprocess.run(
                ["git", "rev-parse", "--is-inside-work-tree"],
                capture_output=True,
                check=False,
                timeout=5,
            ).returncode
            == 0
        )
    except (OSError, subprocess.TimeoutExpired):
        is_git_repository = False
    info = {
        "python": sys.version.split()[0],
        "git": bool(shutil.which("git")),
        "dependencies": {
            name: importlib.util.find_spec(name) is not None
            for name in ("pydantic", "langgraph", "fastapi", "libcst", "typer", "httpx")
        },
        "configuration": "valid",
        "api_key": "configured" if settings.openai_api_key else "not configured",
        "semgrep": bool(shutil.which("semgrep")),
        "bandit": bool(shutil.which("bandit")),
        "gitleaks": bool(shutil.which("gitleaks")),
        "git_repository": is_git_repository,
    }
    try:
        load_policy(".")
    except Exception as exc:
        info["configuration"] = f"invalid: {type(exc).__name__}"
    typer.echo(json.dumps(info, indent=2))


@app.command("eval")
def evaluate(
    dataset: str = typer.Option("eval/dataset.jsonl", "--dataset"),
    offline: bool | None = typer.Option(None, "--offline/--online"),
    max_cases: int | None = typer.Option(None, "--max-cases", min=1),
    seed: int = typer.Option(20260921, "--seed"),
) -> None:
    """Run labeled evaluation with the configured real model by default."""
    from auditmind.evaluation import run_dataset, run_online_dataset

    settings = Settings()
    use_offline = settings.auditmind_offline if offline is None else offline
    try:
        result = (
            run_dataset(Path(dataset))
            if use_offline
            else asyncio.run(run_online_dataset(Path(dataset), settings, max_cases, seed))
        )
        output_name = "mock_summary.json" if use_offline else "online_summary.json"
        output_path = Path("eval/baselines") / output_name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        typer.echo(json.dumps(result, indent=2))
    except Exception as exc:
        typer.echo(f"Evaluation failed: {type(exc).__name__}: {exc}", err=True)
        raise typer.Exit(2) from exc


if __name__ == "__main__":
    app()
