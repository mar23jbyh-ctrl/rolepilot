from auditmind.domain.models import ReviewResult


def render(result: ReviewResult) -> str:
    return result.model_dump_json(indent=2)
