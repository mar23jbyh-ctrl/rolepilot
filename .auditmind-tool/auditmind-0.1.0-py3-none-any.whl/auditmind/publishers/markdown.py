from auditmind.domain.models import ReviewResult


def render(result: ReviewResult) -> str:
    rows = [
        "# AuditMind Review",
        "",
        f"Review: `{result.review_id}` | Mode: **{result.mode}**",
        f"Base: `{result.base_sha[:12]}` | Head: `{result.head_sha[:12]}`",
        f"Decision: **{result.policy.status}** - {result.policy.reason}",
        "",
        "| Severity | Status | Rule | Location | Finding |",
        "|---|---|---|---|---|",
    ]
    for finding in result.findings:
        rows.append(
            f"| {finding.severity} | {finding.verification_status} | "
            f"{finding.rule_id} | `{finding.file_path}:{finding.start_line}` | "
            f"{finding.title.replace('|', ' ')} |"
        )
    if not result.findings:
        rows.append("| - | - | - | - | No verified findings |")
    rows.extend(
        ["", "> Confidence is advisory. The deterministic Policy Engine decides the CI result."]
    )
    if result.errors:
        rows.extend(["", "## Errors", *[f"- {error}" for error in result.errors]])
    return "\n".join(rows) + "\n"
