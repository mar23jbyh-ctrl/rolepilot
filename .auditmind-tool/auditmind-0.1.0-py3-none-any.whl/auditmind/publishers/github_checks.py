from __future__ import annotations

import httpx

from auditmind.domain.errors import AuditMindError
from auditmind.domain.models import ReviewResult
from auditmind.publishers.markdown import render


async def publish_check(
    client: httpx.AsyncClient,
    owner: str,
    repo: str,
    result: ReviewResult,
    previous_id: int | None = None,
) -> dict:
    conclusion = "failure" if result.policy.blocked else "success"
    if result.errors:
        conclusion = "action_required"
    payload = {
        "name": "AuditMind",
        "head_sha": result.head_sha,
        "status": "completed",
        "conclusion": conclusion,
        "external_id": result.review_id,
        "output": {
            "title": f"AuditMind: {result.policy.status}",
            "summary": render(result)[:65000],
        },
    }
    if previous_id is None:
        existing = await client.get(
            f"/repos/{owner}/{repo}/commits/{result.head_sha}/check-runs",
            params={"check_name": "AuditMind", "filter": "all", "per_page": 100},
        )
        if existing.is_error:
            raise AuditMindError(
                f"GitHub Check Run listing failed with HTTP {existing.status_code}"
            )
        previous = next(
            (
                item
                for item in existing.json().get("check_runs", [])
                if item.get("external_id") == result.review_id
            ),
            None,
        )
        previous_id = previous["id"] if previous else None
    response = (
        await client.patch(
            f"/repos/{owner}/{repo}/check-runs/{previous_id}",
            json={key: value for key, value in payload.items() if key not in ("name", "head_sha")},
        )
        if previous_id is not None
        else await client.post(f"/repos/{owner}/{repo}/check-runs", json=payload)
    )
    if response.is_error:
        raise AuditMindError(f"GitHub Check Run failed with HTTP {response.status_code}")
    return response.json()
