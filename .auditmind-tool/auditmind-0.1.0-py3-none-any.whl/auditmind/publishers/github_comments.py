from __future__ import annotations

import re

import httpx

from auditmind.domain.errors import AuditMindError
from auditmind.domain.models import ReviewResult
from auditmind.publishers.markdown import render

MARKER = "<!-- auditmind-review -->"
CHECK_MARKER = re.compile(r"<!-- auditmind-check:([a-f0-9]{16}):([a-f0-9]{40}):([0-9]+) -->")


async def previous_check_id(
    client: httpx.AsyncClient, owner: str, repo: str, pr: int, result: ReviewResult
) -> int | None:
    response = await client.get(
        f"/repos/{owner}/{repo}/issues/{pr}/comments", params={"per_page": 100}
    )
    if response.is_error:
        raise AuditMindError(f"GitHub comment listing failed with HTTP {response.status_code}")
    for comment in response.json():
        body = comment.get("body", "")
        if MARKER not in body:
            continue
        match = CHECK_MARKER.search(body)
        if match and match.group(1) == result.review_id and match.group(2) == result.head_sha:
            return int(match.group(3))
    return None


async def publish_comment(
    client: httpx.AsyncClient,
    owner: str,
    repo: str,
    pr: int,
    result: ReviewResult,
    check_id: int | None = None,
) -> dict:
    url = f"/repos/{owner}/{repo}/issues/{pr}/comments"
    response = await client.get(url, params={"per_page": 100})
    if response.is_error:
        raise AuditMindError(f"GitHub comment listing failed with HTTP {response.status_code}")
    check_marker = (
        f"\n<!-- auditmind-check:{result.review_id}:{result.head_sha}:{check_id} -->"
        if check_id is not None
        else ""
    )
    body = MARKER + "\n" + render(result) + check_marker
    matches = [comment for comment in response.json() if MARKER in comment.get("body", "")]
    old = matches[0] if matches else None
    if old:
        response = await client.patch(
            f"/repos/{owner}/{repo}/issues/comments/{old['id']}", json={"body": body}
        )
    else:
        response = await client.post(url, json={"body": body})
    if response.is_error:
        raise AuditMindError(f"GitHub comment update failed with HTTP {response.status_code}")
    for stale in matches[1:]:
        stale_response = await client.patch(
            f"/repos/{owner}/{repo}/issues/comments/{stale['id']}",
            json={"body": MARKER + "\nOutdated AuditMind review; see current summary."},
        )
        if stale_response.is_error:
            raise AuditMindError(
                f"GitHub stale comment update failed with HTTP {stale_response.status_code}"
            )
    return response.json()
