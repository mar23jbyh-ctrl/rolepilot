"""Review output adapters."""
