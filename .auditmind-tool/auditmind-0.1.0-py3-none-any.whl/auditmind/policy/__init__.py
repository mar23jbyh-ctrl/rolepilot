"""Deterministic CI gate."""
