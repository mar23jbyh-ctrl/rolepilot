from auditmind.config import PolicyConfig
from auditmind.domain.enums import VerificationStatus
from auditmind.domain.models import Finding, PolicyDecision


def decide(findings: list[Finding], config: PolicyConfig) -> PolicyDecision:
    eligible = [
        f
        for f in findings
        if f.category in config.categories and not config.ignored(f.rule_id, f.file_path)
    ]
    blockers = [
        f
        for f in eligible
        if f.verification_status == VerificationStatus.CONFIRMED
        and f.severity in config.fail_on
        and (not config.require_evidence or f.evidence.code)
    ]
    if blockers:
        return PolicyDecision(
            status="BLOCKED",
            blocked=True,
            reason=f"{len(blockers)} confirmed high-risk finding(s)",
            triggering_rules=sorted({f.rule_id for f in blockers}),
        )
    if any(f.verification_status == VerificationStatus.UNCERTAIN for f in eligible):
        if not config.allow_uncertain:
            return PolicyDecision(
                status="FAILED",
                blocked=True,
                reason="Policy does not allow uncertain findings",
            )
        return PolicyDecision(
            status="REVIEW REQUIRED",
            blocked=False,
            reason="Uncertain finding requires human review",
        )
    return PolicyDecision(status="PASSED", blocked=False, reason="No blocking confirmed findings")
