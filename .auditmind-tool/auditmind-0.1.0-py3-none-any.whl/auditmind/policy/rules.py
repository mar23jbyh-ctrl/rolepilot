from auditmind.domain.enums import VerificationStatus
from auditmind.domain.models import Finding


def publishable(finding: Finding) -> bool:
    return finding.verification_status != VerificationStatus.REJECTED
