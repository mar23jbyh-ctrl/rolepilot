from __future__ import annotations

import ast
from dataclasses import dataclass

import libcst


@dataclass
class Symbol:
    name: str
    kind: str
    start: int
    end: int
    calls: list[str]


@dataclass
class ParsedPython:
    symbols: list[Symbol]
    imports: list[tuple[int, str]]
    incomplete: bool = False


def parse_python(source: str) -> ParsedPython:
    try:
        # CST validates syntax without rewriting source or its line positions.
        libcst.parse_module(source)
        tree = ast.parse(source)
    except (SyntaxError, libcst.ParserSyntaxError, ValueError):
        return ParsedPython([], [], True)
    symbols: list[Symbol] = []
    imports: list[tuple[int, str]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.parents: list[str] = []

        def visit_Import(self, node: ast.Import) -> None:
            imports.append((node.lineno, ast.get_source_segment(source, node) or ""))

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            imports.append((node.lineno, ast.get_source_segment(source, node) or ""))

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            self._symbol(node, "class")

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self._symbol(node, "function")

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self._symbol(node, "function")

        def _symbol(self, node: ast.AST, kind: str) -> None:
            name = node.name
            full = ".".join([*self.parents, name])
            calls = []
            for item in ast.walk(node):
                if isinstance(item, ast.Call):
                    call = ast.get_source_segment(source, item.func) or ""
                    calls.append(call)
            symbols.append(Symbol(full, kind, node.lineno, node.end_lineno or node.lineno, calls))
            self.parents.append(name)
            self.generic_visit(node)
            self.parents.pop()

    Visitor().visit(tree)
    return ParsedPython(symbols, imports)


def enclosing(parsed: ParsedPython, line: int) -> Symbol | None:
    matches = [s for s in parsed.symbols if s.start <= line <= s.end]
    return min(matches, key=lambda s: s.end - s.start, default=None)
