from auditmind.context.python_parser import ParsedPython, Symbol


def related_symbols(parsed: ParsedPython, symbol: Symbol) -> list[Symbol]:
    calls = {call.split(".")[-1] for call in symbol.calls}
    return [s for s in parsed.symbols if s is not symbol and s.name.split(".")[-1] in calls]
