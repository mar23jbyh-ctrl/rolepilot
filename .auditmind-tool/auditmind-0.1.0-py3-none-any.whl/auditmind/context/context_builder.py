from __future__ import annotations

from auditmind.context.context_ranker import select
from auditmind.context.dependency_graph import related_symbols
from auditmind.context.keyword_index import KeywordIndex
from auditmind.context.python_parser import enclosing, parse_python
from auditmind.domain.models import ChangedFile, ContextBundle, ContextSnippet
from auditmind.git.repository import GitRepository


def build_context(
    repo: GitRepository, head: str, files: list[ChangedFile], token_budget: int
) -> ContextBundle:
    candidates: list[ContextSnippet] = []
    manifest: list[str] = []
    incomplete = False
    for file in files:
        if not file.path.endswith(".py") or file.status == "deleted":
            continue
        source = repo.source(head, file.path)
        if source is None:
            incomplete = True
            manifest.append(f"{file.path}: source unavailable")
            continue
        rows = source.splitlines()
        parsed = parse_python(source)
        incomplete |= parsed.incomplete
        changed = {line.new_line for line in file.lines if line.kind == "add"}
        for line_no in sorted(changed):
            if line_no is None or line_no > len(rows):
                continue
            candidates.append(
                ContextSnippet(
                    file_path=file.path,
                    start_line=line_no,
                    end_line=line_no,
                    kind="changed",
                    code=rows[line_no - 1],
                    score=100,
                )
            )
            symbol = enclosing(parsed, line_no)
            if symbol:
                code = "\n".join(rows[symbol.start - 1 : symbol.end])
                candidates.append(
                    ContextSnippet(
                        file_path=file.path,
                        start_line=symbol.start,
                        end_line=symbol.end,
                        kind="enclosing",
                        symbol=symbol.name,
                        code=code,
                        score=60,
                    )
                )
                for related in related_symbols(parsed, symbol)[:3]:
                    candidates.append(
                        ContextSnippet(
                            file_path=file.path,
                            start_line=related.start,
                            end_line=related.end,
                            kind="related_function",
                            symbol=related.name,
                            code="\n".join(rows[related.start - 1 : related.end]),
                            score=30,
                        )
                    )
        for number, code in parsed.imports[:20]:
            candidates.append(
                ContextSnippet(
                    file_path=file.path,
                    start_line=number,
                    end_line=number,
                    kind="import",
                    code=code,
                    score=20,
                )
            )
        manifest.append(f"{file.path}: {len(changed)} changed lines, {len(parsed.symbols)} symbols")
    changed_paths = {file.path for file in files}
    stems = {file.path.rsplit("/", 1)[-1].removesuffix(".py") for file in files}
    index = KeywordIndex()
    for path in repo.tracked_paths(head):
        index.add(path)
    matched_paths = set()
    for stem in stems:
        matched_paths.update(index.search(stem))
    related_count = 0
    for path in sorted(matched_paths):
        if related_count >= 8:
            break
        if path in changed_paths:
            continue
        name = path.rsplit("/", 1)[-1]
        is_test = name.startswith("test_") and any(stem in name for stem in stems)
        is_schema = ("schema" in path.lower() or "model" in path.lower()) and any(
            stem in path.lower() for stem in stems
        )
        if not (is_test or is_schema):
            continue
        source = repo.source(head, path)
        if source is None:
            continue
        rows = source.splitlines()
        excerpt = rows[:60]
        if not excerpt:
            continue
        candidates.append(
            ContextSnippet(
                file_path=path,
                start_line=1,
                end_line=len(excerpt),
                kind="related_test" if is_test else "related_schema",
                code="\n".join(excerpt),
                score=15 if is_test else 12,
            )
        )
        related_count += 1
        manifest.append(f"{path}: related {'test' if is_test else 'schema'}")
        incomplete |= len(rows) > len(excerpt)
    selected, used = select(candidates, token_budget)
    return ContextBundle(
        snippets=selected,
        manifest=manifest,
        incomplete=incomplete or len(selected) < len(candidates),
        token_estimate=used,
    )
