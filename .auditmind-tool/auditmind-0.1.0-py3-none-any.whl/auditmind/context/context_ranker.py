from auditmind.domain.models import ContextSnippet


def select(snippets: list[ContextSnippet], token_budget: int) -> tuple[list[ContextSnippet], int]:
    used = 0
    selected = []
    seen: set[tuple[str, int, int]] = set()
    for snippet in sorted(snippets, key=lambda item: -item.score):
        key = (snippet.file_path, snippet.start_line, snippet.end_line)
        cost = max(1, len(snippet.code) // 4)
        if key not in seen and used + cost <= token_budget:
            selected.append(snippet)
            used += cost
            seen.add(key)
    return selected, used
