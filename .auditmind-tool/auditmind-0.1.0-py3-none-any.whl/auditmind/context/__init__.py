"""Bounded structural context extraction."""
