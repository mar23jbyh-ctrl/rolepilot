from __future__ import annotations

import re
import sqlite3


class KeywordIndex:
    """Ephemeral FTS5 index of repository paths; no source code is persisted."""

    def __init__(self) -> None:
        self.db = sqlite3.connect(":memory:")
        self.db.execute("CREATE VIRTUAL TABLE paths USING fts5(path UNINDEXED, terms)")

    def add(self, path: str) -> None:
        terms = re.sub(r"[^a-zA-Z0-9]+", " ", path)
        self.db.execute("INSERT INTO paths VALUES (?,?)", (path, terms))

    def search(self, word: str, limit: int = 30) -> list[str]:
        if not re.fullmatch(r"[a-zA-Z0-9]+", word):
            return []
        return [
            row[0]
            for row in self.db.execute(
                "SELECT path FROM paths WHERE terms MATCH ? LIMIT ?", (word, limit)
            )
        ]
