from __future__ import annotations

import uuid

from auditmind.config import Settings, load_policy
from auditmind.domain.models import ReviewRequest, ReviewResult
from auditmind.llm.cache import ModelCache
from auditmind.llm.client import ModelClient
from auditmind.llm.model_router import mode
from auditmind.storage.repositories import ReviewRepository
from auditmind.workflow.graph import build_graph
from auditmind.workflow.nodes import Nodes


async def run_review(
    request: ReviewRequest, settings: Settings | None = None, persist: bool = True,
    cache: bool = True,
) -> ReviewResult:
    settings = settings or Settings()
    mode(settings, request.offline)
    policy = load_policy(request.repo)
    if request.model and not request.offline:
        settings.auditmind_model = request.model
    elif "auditmind_model" not in settings.model_fields_set:
        settings.auditmind_model = policy.model
    client = (
        None
        if request.offline
        else ModelClient(
            settings,
            ModelCache(settings.auditmind_db_path) if cache else None,
            policy.timeout_seconds,
        )
    )
    graph = build_graph(Nodes(settings, policy, client))
    state = await graph.ainvoke(
        {
            "request": request,
            "trace_id": uuid.uuid4().hex,
            "errors": [],
            "token_usage": 0,
            "stages": [],
        }
    )
    result = state["report"]
    if persist:
        ReviewRepository(settings.auditmind_db_path).save(result)
    return result
